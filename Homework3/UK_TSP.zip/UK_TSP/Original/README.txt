UK12 describes 12 cities, with integer distances representing the travel time, in minutes, between pairs of cities.
- uk12_main.txt, is the main file.
- uk12_code.txt, contains a code for each city.
- uk12_dist.txt, the city-to-city distance matrix.
- uk12_name.txt, the name of each city.
- uk12_xy.txt, the (X,Y) coordinates of each city, estimated from the distance table.
- uk12_xy.png, a PNG image of the (X,Y) coordinates of each city.


https://people.sc.fsu.edu/~jburkardt/datasets/cities/cities.html